<?php
namespace Aws\Exception;

class UnresolvedSignatureException extends \RuntimeException {}
