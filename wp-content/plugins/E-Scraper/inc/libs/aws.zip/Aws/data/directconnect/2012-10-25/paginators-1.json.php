<?php
// This file was auto-generated from sdk-root/src/data/directconnect/2012-10-25/paginators-1.json
return [ 'pagination' => [ 'DescribeConnections' => [ 'result_key' => 'connections', ], 'DescribeConnectionsOnInterconnect' => [ 'result_key' => 'connections', ], 'DescribeInterconnects' => [ 'result_key' => 'interconnects', ], 'DescribeLocations' => [ 'result_key' => 'locations', ], 'DescribeVirtualGateways' => [ 'result_key' => 'virtualGateways', ], 'DescribeVirtualInterfaces' => [ 'result_key' => 'virtualInterfaces', ], ],];
