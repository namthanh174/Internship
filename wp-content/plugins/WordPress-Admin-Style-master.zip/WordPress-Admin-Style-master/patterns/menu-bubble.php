<h2>Menu Bubble</h2>

	<ul id="adminmenu"> <!-- only for view in this plugin, not relevant in WP menu -->
		<li style="padding:1em;"> <!-- only for view in this plugin, not relevant in WP menu -->
<span class="update-plugins count-123"><span class="plugin-count">123</span></span>
		</li> <!-- only for view in this plugin, not relevant in WP menu -->
	</ul> <!-- only for view in this plugin, not relevant in WP menu -->
