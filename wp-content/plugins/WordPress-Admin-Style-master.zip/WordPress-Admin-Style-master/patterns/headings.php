<h2><?php _e( 'Headings', 'wp_admin_style' ); ?></h2>

<h1><code>h1</code> <?php echo $this->get_plugin_data( 'Name' ) ?></h1>
<h2><code>h2</code> <?php echo $this->get_plugin_data( 'Name' ) ?></h2>
<h3><code>h3</code> <?php echo $this->get_plugin_data( 'Name' ) ?></h3>
<h4><code>h4</code> <?php echo $this->get_plugin_data( 'Name' ) ?></h4>
